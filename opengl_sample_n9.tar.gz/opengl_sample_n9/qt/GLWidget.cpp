#include "GLWidget.hpp"

#include "../renderer/renderer.h"

#include <QtOpenGL/QGLShaderProgram>

#include <QBasicTimer>
#include <QMouseEvent>

#include <math.h>

#include <QDebug>

GLWidget::GLWidget(QWidget *parent) :
  QGLWidget(parent),
  timer(new QBasicTimer)
{
}

GLWidget::GLWidget(const QGLFormat& format, QWidget *parent) :
  QGLWidget(format, parent),
  timer(new QBasicTimer)
{
}

GLWidget::~GLWidget()
{
  delete timer; timer = 0;
  renderer_kill();
}

void GLWidget::mousePressEvent(QMouseEvent *e)
{
  // Saving mouse press position
  mousePressPosition = QVector2D(e->posF());
}


void GLWidget::mouseMoveEvent(QMouseEvent *e)
{
  // Current mouse position - mouse press position
  QVector2D diff = QVector2D(e->posF()) - mousePressPosition;
  mousePressPosition = QVector2D(e->posF());
  float d_theta = 0;
  float d_psi = 0;
  float d_distance = 0;

  if(e->buttons() & Qt::LeftButton)
    {
      d_theta = diff.y();
      d_psi = diff.x();
    }

  if(e->buttons() & Qt::RightButton)
    {
      d_distance = diff.y() / 10.0;
    }

  if(d_theta || d_psi || d_distance)
    {
      renderer_move(d_theta, d_psi, d_distance);
      updateGL();
    }
}

void GLWidget::timerEvent(QTimerEvent *e)
{
  Q_UNUSED(e);
  if(frame_counter) 
    {
    /*
      static char title[64];
      snprintf(title, sizeof(title), "%d Frames Per Second", frame_counter * 1000 / 41);
      fprintf(stdout, "%d\n", frame_counter);
      setWindowTitle(title);
    */
    }
  updateGL();
}

void GLWidget::initializeGL()
{
  int err;
  err = renderer_init();
  if(err)
    {
      close();
    }

  frame_counter = 0;

  // using QBasicTimer because its faster that QTimer
  timer->start(41, this);
}

void GLWidget::resizeGL(int w, int h)
{
  renderer_reshape(w, h);
}

void GLWidget::paintGL()
{
  double date;
  struct timespec ts;
  clock_gettime(CLOCK_REALTIME, &ts);
  date = ts.tv_sec + ts.tv_nsec / 1000000000.0;

  renderer_display(date);

  swapBuffers();

  frame_counter++;
}
