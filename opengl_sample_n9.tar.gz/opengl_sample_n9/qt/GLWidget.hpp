#ifndef GLWIDGET_HPP
#define GLWIDGET_HPP

#include <QtOpenGL/QGLWidget>
#include <QVector2D>

class QMouseEvent;
class QBasicTimer;

class GLWidget : public QGLWidget
{
    Q_OBJECT
public:
    explicit GLWidget(QWidget *parent = 0);
    explicit GLWidget(const QGLFormat& format, QWidget *parent = 0);
    virtual ~GLWidget();

signals:

public slots:

protected:
    void mousePressEvent(QMouseEvent *e);
    void mouseMoveEvent(QMouseEvent *e);
    void timerEvent(QTimerEvent *e);

    void initializeGL();
    void resizeGL(int w, int h);
    void paintGL();

private:
    QBasicTimer *timer;
    QVector2D mousePressPosition;

  unsigned frame_counter;
};

#endif // GLWIDGET_H
