#include <QApplication>
#if 0
#include "MainWindow.hpp"
#else
#include "GLWidget.hpp"
#endif

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);

#if 0
  MainWindow mw;
  mw.showFullScreen();
#else
  GLWidget glwidget;
  glwidget.showFullScreen();
#endif

  return a.exec();
}
