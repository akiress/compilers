#include <QGridLayout>

#include "MainWindow.hpp"
#ifndef QT_NO_OPENGL
#include "GLWidget.hpp"
#endif

MainWindow::MainWindow()
{
#ifndef QT_NO_OPENGL

    // Specify an OpenGL 4.0 format using the Core profile.
    // That is, no old-school fixed pipeline functionality
    QGLFormat glFormat;
    //glFormat.setVersion(4, 0);
    //glFormat.setProfile(QGLFormat::CoreProfile); // Requires >=Qt-4.8.0

    GLWidget *glwidget = new GLWidget(glFormat, this);

    setCentralWidget(glwidget);

#else

    QLabel *label = new QLabel(this, "OpenGL Support required");

    setCentralWidget(label);

#endif

}
