#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "common.h"
#include <GL/freeglut.h>

#include "renderer.h"

/*****************************************************************************
 * mouse state                                                               *
 *****************************************************************************/

typedef struct 
{
  int  pos_x;
  int  pos_y;
  char btn_r;
  char btn_m;
  char btn_l;
} mouse_state_t;

static mouse_state_t mouse_state = {0};

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static unsigned frame_counter = 0;

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static void keyboard(unsigned char key,int x,int y)
{
  switch(key)
    {
    case 27:
      glutLeaveMainLoop();
    case 'a':
      break;
    case 'b':
      break;
    case 'c':
      break;
    case 'd':
      break;
    default:
      break;
    }
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static void mouse(int button, int state, int x, int y)
{
    if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
    {
	mouse_state.btn_l = 1;
	mouse_state.pos_x = x;
	mouse_state.pos_y = y;
    }
    if(button == GLUT_LEFT_BUTTON && state == GLUT_UP)
    {
    	mouse_state.btn_l = 0;
    }
    if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
    {
	mouse_state.btn_r = 1;
	mouse_state.pos_x = x;
	mouse_state.pos_y = y;
    }
    if(button == GLUT_RIGHT_BUTTON && state == GLUT_UP)
    {
	mouse_state.btn_r = 0;
    }
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static void motion(int x, int y)
{
  float d_theta = 0;
  float d_psi = 0;
  float d_distance = 0;

  if(mouse_state.btn_l)
    {
      d_theta = y - mouse_state.pos_y;
      d_psi   = x - mouse_state.pos_x;

      mouse_state.pos_x = x;
      mouse_state.pos_y = y;
    }

  if(mouse_state.btn_r)
    {
      d_distance = (y - mouse_state.pos_y) / 10.0;

      mouse_state.pos_y = y;
    }

  if(d_theta || d_psi || d_distance)
    {
      renderer_move(d_theta, d_psi, d_distance);
      glutPostRedisplay();
    }
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static void reshape(int w, int h)
{
  renderer_reshape(w, h);	
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static void display(void)
{
  double date;
  struct timespec ts;
  clock_gettime(CLOCK_REALTIME, &ts);
  date = ts.tv_sec + ts.tv_nsec / 1000000000.0;
  
  renderer_display(date);

  glutSwapBuffers();

  frame_counter++;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static void idle(void)
{
  glutPostRedisplay();
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static void timer(int value)
{
  if(frame_counter) 
    {
      static char title[64];
      snprintf(title, sizeof(title), "%d Frames Per Second", frame_counter);
      glutSetWindowTitle(title);
    }
  frame_counter = 0;
  glutTimerFunc(1000, timer, value);
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
int main(int argc,char **argv)
{
  glutInit(&argc,argv);

  glutInitContextVersion(4, 0);
  glutInitContextFlags(GLUT_FORWARD_COMPATIBLE);
  glutInitContextProfile(GLUT_CORE_PROFILE);

  glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);

  glutInitWindowSize(600,600);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
  int window_handle = glutCreateWindow(argv[0]);
  if(window_handle < 1) 
    {
      fprintf(stderr, "ERROR: Could not create a new rendering window.\n");
      exit(EXIT_FAILURE);
    }

  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutKeyboardFunc(keyboard);
  glutMouseFunc(mouse);
  glutMotionFunc(motion);
  glutIdleFunc(idle);
  glutTimerFunc(0, timer, 0);

#if defined(USE_GLEW)
  GLenum glew_init_result = glewInit();
  if(GLEW_OK != glew_init_result) 
    {
      fprintf(stderr, "ERROR: %s\n", glewGetErrorString(glew_init_result));
      exit(EXIT_FAILURE);
    }
  fprintf(stdout, "OpenGL Version: %s\n", glGetString(GL_VERSION));
#endif

  int err;
  err = renderer_init();

  if(!err)
    {
      glutMainLoop();
    }

  renderer_kill();

  return err?EXIT_FAILURE:EXIT_SUCCESS;
}
