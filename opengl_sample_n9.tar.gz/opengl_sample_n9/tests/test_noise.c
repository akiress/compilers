#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include <time.h>
#include <SDL/SDL.h>

#include "noise_data.h"

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

#if 1
typedef float real_t;
#define math_abs    fabs
#define math_pow    powf
#define math_floor  floorf
#define math_log    logf
#else
typedef double real_t;
#define math_abs    abs
#define math_pow    pow
#define math_floor  floor
#define math_log    log
#endif

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static inline real_t mix(real_t x, real_t y, real_t a)
{ 
  return x * (1 - a) + y * a; 
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static inline real_t dot(const char * a, real_t x, real_t y, real_t z)
{
  return a[0] * x + a[1] * y + a[2] * z;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static inline real_t fade(real_t t)
{ 
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0); 
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static real_t noise1(const real_t * vec) 
{
  real_t x = vec[0];
  real_t y = vec[1];
  real_t z = vec[2];
  /* FIND UNIT CUBE THAT CONTAINS POINT. */
  int grid_x = (int)math_floor(x);
  int grid_y = (int)math_floor(y);
  int grid_z = (int)math_floor(z);
  /* FIND RELATIVE X,Y,Z OF POINT IN CUBE. */
  x -= grid_x;
  y -= grid_y;
  z -= grid_z;
  /* COMPUTE FADE CURVES FOR EACH OF X,Y,Z. */
  real_t fad_x = fade(x); 
  real_t fad_y = fade(y); 
  real_t fad_z = fade(z);
  /* CLAMP GRID */
  grid_x &= 255;
  grid_y &= 255;
  grid_z &= 255;
  /* HASH COORDINATES OF THE 8 CUBE CORNERS */
#if 1
  unsigned char perm000 = p(p(p(grid_x + 0) + grid_y + 0) + grid_z + 0);
  unsigned char perm100 = p(p(p(grid_x + 1) + grid_y + 0) + grid_z + 0);
  unsigned char perm010 = p(p(p(grid_x + 0) + grid_y + 1) + grid_z + 0);
  unsigned char perm110 = p(p(p(grid_x + 1) + grid_y + 1) + grid_z + 0);
  unsigned char perm001 = p(p(p(grid_x + 0) + grid_y + 0) + grid_z + 1);
  unsigned char perm101 = p(p(p(grid_x + 1) + grid_y + 0) + grid_z + 1);
  unsigned char perm011 = p(p(p(grid_x + 0) + grid_y + 1) + grid_z + 1);
  unsigned char perm111 = p(p(p(grid_x + 1) + grid_y + 1) + grid_z + 1);
  const char * grad000 = g(perm000);
  const char * grad100 = g(perm100);
  const char * grad010 = g(perm010);
  const char * grad110 = g(perm110);
  const char * grad001 = g(perm001);
  const char * grad101 = g(perm101);
  const char * grad011 = g(perm011);
  const char * grad111 = g(perm111);
#else
  char grad000[3] = 
    {
      perlin_lookup_data[grid_z + 0][grid_y + 0][grid_x + 0][0] / 64 - 1, 
      perlin_lookup_data[grid_z + 0][grid_y + 0][grid_x + 0][1] / 64 - 1, 
      perlin_lookup_data[grid_z + 0][grid_y + 0][grid_x + 0][2] / 64 - 1
    };
  assert(-1 <= grad000[0] && grad000[0] <= 1);
  assert(-1 <= grad000[1] && grad000[1] <= 1);
  assert(-1 <= grad000[2] && grad000[2] <= 1);
  char grad100[3] =
    {
      perlin_lookup_data[grid_z + 0][grid_y + 0][grid_x + 1][0] / 64 - 1, 
      perlin_lookup_data[grid_z + 0][grid_y + 0][grid_x + 1][1] / 64 - 1, 
      perlin_lookup_data[grid_z + 0][grid_y + 0][grid_x + 1][2] / 64 - 1
    };
  assert(-1 <= grad100[0] && grad100[0] <= 1);
  assert(-1 <= grad100[1] && grad100[1] <= 1);
  assert(-1 <= grad100[2] && grad100[2] <= 1);
  char grad010[3] =
    {
      perlin_lookup_data[grid_z + 0][grid_y + 1][grid_x + 0][0] / 64 - 1, 
      perlin_lookup_data[grid_z + 0][grid_y + 1][grid_x + 0][1] / 64 - 1, 
      perlin_lookup_data[grid_z + 0][grid_y + 1][grid_x + 0][2] / 64 - 1
    };
  assert(-1 <= grad010[0] && grad010[0] <= 1);
  assert(-1 <= grad010[1] && grad010[1] <= 1);
  assert(-1 <= grad010[2] && grad010[2] <= 1);
  char grad110[3] =
    {
      perlin_lookup_data[grid_z + 0][grid_y + 1][grid_x + 1][0] / 64 - 1, 
      perlin_lookup_data[grid_z + 0][grid_y + 1][grid_x + 1][1] / 64 - 1, 
      perlin_lookup_data[grid_z + 0][grid_y + 1][grid_x + 1][2] / 64 - 1
    };
  assert(-1 <= grad110[0] && grad110[0] <= 1);
  assert(-1 <= grad110[1] && grad110[1] <= 1);
  assert(-1 <= grad110[2] && grad110[2] <= 1);
  char grad001[3] =
    {
      perlin_lookup_data[grid_z + 1][grid_y + 0][grid_x + 0][0] / 64 - 1, 
      perlin_lookup_data[grid_z + 1][grid_y + 0][grid_x + 0][1] / 64 - 1, 
      perlin_lookup_data[grid_z + 1][grid_y + 0][grid_x + 0][2] / 64 - 1
    };
  assert(-1 <= grad001[0] && grad001[0] <= 1);
  assert(-1 <= grad001[1] && grad001[1] <= 1);
  assert(-1 <= grad001[2] && grad001[2] <= 1);
  char grad101[3] =
    {
      perlin_lookup_data[grid_z + 1][grid_y + 0][grid_x + 1][0] / 64 - 1, 
      perlin_lookup_data[grid_z + 1][grid_y + 0][grid_x + 1][1] / 64 - 1, 
      perlin_lookup_data[grid_z + 1][grid_y + 0][grid_x + 1][2] / 64 - 1
    };
  assert(-1 <= grad101[0] && grad101[0] <= 1);
  assert(-1 <= grad101[1] && grad101[1] <= 1);
  assert(-1 <= grad101[2] && grad101[2] <= 1);
  char grad011[3] =
    {
      perlin_lookup_data[grid_z + 1][grid_y + 1][grid_x + 0][0] / 64 - 1, 
      perlin_lookup_data[grid_z + 1][grid_y + 1][grid_x + 0][1] / 64 - 1, 
      perlin_lookup_data[grid_z + 1][grid_y + 1][grid_x + 0][2] / 64 - 1
    };
  assert(-1 <= grad011[0] && grad011[0] <= 1);
  assert(-1 <= grad011[1] && grad011[1] <= 1);
  assert(-1 <= grad011[2] && grad011[2] <= 1);
  char grad111[3] =
    {
      perlin_lookup_data[grid_z + 1][grid_y + 1][grid_x + 1][0] / 64 - 1, 
      perlin_lookup_data[grid_z + 1][grid_y + 1][grid_x + 1][1] / 64 - 1, 
      perlin_lookup_data[grid_z + 1][grid_y + 1][grid_x + 1][2] / 64 - 1
    };
  assert(-1 <= grad111[0] && grad111[0] <= 1);
  assert(-1 <= grad111[1] && grad111[1] <= 1);
  assert(-1 <= grad111[2] && grad111[2] <= 1);
#endif
  real_t noise000 = dot(grad000, x    , y    , z    );
  real_t noise100 = dot(grad100, x - 1, y    , z    );
  real_t noise010 = dot(grad010, x    , y - 1, z    );
  real_t noise110 = dot(grad110, x - 1, y - 1, z    );
  real_t noise001 = dot(grad001, x    , y    , z - 1);
  real_t noise101 = dot(grad101, x - 1, y    , z - 1);
  real_t noise011 = dot(grad011, x    , y - 1, z - 1);
  real_t noise111 = dot(grad111, x - 1, y - 1, z - 1);
  /* AND ADD BLENDED RESULTS FROM 8 CORNERS OF CUBE */
  return mix(mix(mix(noise000,
                     noise100,
                     fad_x),                                  
                 mix(noise010,
                     noise110,
                     fad_x),
                 fad_y),                                      
             mix(mix(noise001,
                     noise101,
                     fad_x),
                 mix(noise011,
                     noise111,
                     fad_x),
                 fad_y),
             fad_z);
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

#define SCREEN_WIDTH  256
#define SCREEN_HEIGHT 256
#define SCREEN_DEPTH  32

static double   frequency = 2; 
static double   zoom = 1;   
static unsigned anim = 0;
static unsigned frame = 0;
static unsigned nb_samples = 0;
static double   avg = 0;

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static Uint8 color_map(double n)
{
    if(1 <= n)
    {
	return 255;
    }
    else if(n <= 0)
    {
	return 0;
    }
    else
    {
	return n * 255;
    }
}


/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static void color_map_01(double u, double v, double w, Uint8 *r, Uint8 *g, Uint8 *b)
{
    real_t vec[3];
    vec[0] = u * zoom;
    vec[1] = v * zoom;
    vec[2] = w * zoom;
    double n = noise1(vec) * 0.5 + 0.5;

    *r = color_map(n);
    *g = color_map(n);
    *b = color_map(n);
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static void test_perlin(SDL_Surface * surface)
{
    int y;
    int x;
    for(y = 0; y < surface->h; y++)
    {
	for(x = 0;x < surface->w; x++)
	{
            /* let u,v,w be in [0;1] */
	    double u =       (double)x / surface->w;
	    double v = 1.0 - (double)y / surface->h;
	    double w = frame * 0.1;
	    
	    Uint8 r;
	    Uint8 g;
	    Uint8 b;
	    Uint32 color;

	    struct timespec start_date;
	    struct timespec end_date;
	    double elapsed_time;

	    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &start_date);

#if 1
	    color_map_01(u, v, w, &r, &g, &b);
#elif 0
	    color_map_02(u, v, w, &r, &g, &b);
#endif
	    color = SDL_MapRGB(surface->format, r, g, b);

	    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &end_date);
	    elapsed_time = 
		(end_date.tv_sec + end_date.tv_nsec / 1000000000.0) - 
		(start_date.tv_sec + start_date.tv_nsec / 1000000000.0);

	    nb_samples++;

	    avg = avg + (elapsed_time - avg) / nb_samples; 

	    *((Uint32*)(surface->pixels) + x + y * surface->w) = color;
	}
    } 
    if(anim)
    {
	frame++;
    }
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/


int main(int argc, char *argv[]) 
{
  SDL_Surface *screen;
  SDL_Event event;
  int done = 0;
    
  if (SDL_Init(SDL_INIT_VIDEO) < 0 ) 
    {
      return 1;
    }

  screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_DEPTH, SDL_SWSURFACE);
  if (!screen)
    {
      SDL_Quit();
      return 1;
    }
 
  while(!done) 
    {
      if(SDL_MUSTLOCK(screen)) 
	{
	  if(SDL_LockSurface(screen) < 0) 
	    {
	      break;
	    }
	}

      test_perlin(screen);
	
      if(SDL_MUSTLOCK(screen))
	{
	  SDL_UnlockSurface(screen);
	}

      SDL_Flip(screen);

      while(SDL_PollEvent(&event)) 
	{      
	  if ( event.type == SDL_QUIT ) 
	    { 
	      done = 1;  
	    }

	  else if ( event.type == SDL_KEYDOWN )
	    {
	      if ( event.key.keysym.sym == SDLK_ESCAPE ) 
		{ 
		  done = 1;
		}
	      else if ( event.key.keysym.sym == SDLK_f ) 
		{ 
		  frequency += 0.1;
		  fprintf(stdout, "frequency = %f\n", frequency);
		}
	      else if ( event.key.keysym.sym == SDLK_d ) 
		{ 
		  frequency -= 0.1;
		  fprintf(stdout, "frequency = %f\n", frequency);
		}
	      else if ( event.key.keysym.sym == SDLK_z ) 
		{ 
		  zoom += 0.2;
		  fprintf(stdout, "zoom = %f\n", zoom);
		}
	      else if ( event.key.keysym.sym == SDLK_a ) 
		{ 
		  zoom -= 0.2;
		  fprintf(stdout, "zoom = %f\n", zoom);
		}
	      else if ( event.key.keysym.sym == SDLK_p ) 
		{ 
		  anim = 1 - anim;
		  fprintf(stdout, "anim = %d\n", anim);
		}
	    }
	}
    }

  fprintf(stdout, "avg = %fs (%u samples)\n", avg, nb_samples);

  SDL_Quit();
  
  return 0;
}
