#ifndef __common_h__
#define __common_h__

//#define USE_GL3_GL3
//#define USE_GLES2_GL2

#if defined(USE_GLEW)

#include <GL/glew.h>

#define USE_UNIFORM_BLOCK_OBJECT
#define USE_VERTEX_ARRAY_OBJECT

#define VERT_SHADER_EXT "vert"
#define FRAG_SHADER_EXT "frag"

#elif defined(USE_GL3_GL3)

#define GL3_PROTOTYPES
#include <GL3/gl3.h>
#define __gl_h_

#define USE_UNIFORM_BLOCK_OBJECT
#define USE_VERTEX_ARRAY_OBJECT

#define VERT_SHADER_EXT "vert"
#define FRAG_SHADER_EXT "frag"

#elif defined(USE_GLES2_GL2)

#include <GLES2/gl2.h>
#define __gl_h_

#if !defined(GL_INVALID_INDEX)
#define GL_INVALID_INDEX 0xFFFFFFFFu
#endif

#undef USE_UNIFORM_BLOCK_OBJECT
#undef USE_VERTEX_ARRAY_OBJECT

#define VERT_SHADER_EXT "es.vert"
#define FRAG_SHADER_EXT "es.frag"

#else

#error "You have to define USE_GLEW or USE_GL3_GL3 or USE_GLES2_GL2"

#endif


void clear_gl_error(void);
void check_gl_error(const char * file, int line);

#define CLEAR_GL_ERROR() do { clear_gl_error();                   } while(0)
#define CHECK_GL_ERROR() do { check_gl_error(__FILE__, __LINE__); } while(0)

#endif /* __common_h__ */
