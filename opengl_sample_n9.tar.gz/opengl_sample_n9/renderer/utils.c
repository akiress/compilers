#include <string.h>
#include <math.h>

#include "utils.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846  /* pi */
#endif

#define COTANGENT(angle)         (1.0 / tan(angle))
#define DEGREE_TO_RADIAN(degree) ((degree) * M_PI / 180.0)

void my_glMultMatrix(GLfloat* m1, const GLfloat* m2)
{
  unsigned int row, column, row_offset;
  GLfloat tmp[16];
  for(row = 0, row_offset = row * 4; row < 4; ++row, row_offset = row * 4)
    {
      for (column = 0; column < 4; ++column)
	{
	  tmp[row_offset + column] =
	    (m2[row_offset + 0] * m1[column + 0]) +
	    (m2[row_offset + 1] * m1[column + 4]) +
	    (m2[row_offset + 2] * m1[column + 8]) +
	    (m2[row_offset + 3] * m1[column + 12]);
	}
    }
  memcpy(m1, tmp, 16 * sizeof(*tmp));
}

void my_glLoadIdentity(GLfloat * m)
{
  memset(m, 0, 16 * sizeof(*m));
  m[0]  = 1;
  m[5]  = 1;
  m[10] = 1;
  m[15] = 1;

}

void my_gluPerspective(GLfloat * m,
		       GLfloat fovy,
		       GLfloat aspect,
		       GLfloat near,
		       GLfloat far)
{
  if(fovy && aspect && (near != far))
    {
      GLfloat fovy_rad = DEGREE_TO_RADIAN(fovy / 2);
      GLfloat y_scale = COTANGENT(fovy_rad);
      GLfloat x_scale = y_scale / aspect;
      GLfloat frustum_length = far - near;
      m[0]  = x_scale;
      m[5]  = y_scale;
      m[10] = -((far + near) / frustum_length);
      m[11] = -1;
      m[14] = -((2 * near * far) / frustum_length);
    }
}

void my_glTranslatef(GLfloat * m,
		     GLfloat x,
		     GLfloat y,
		     GLfloat z)
{
  GLfloat t[16];
  my_glLoadIdentity(t);
  t[12] = x;
  t[13] = y;
  t[14] = z;

  my_glMultMatrix(m, t);
}

void my_glRotatef(GLfloat * m,
		  GLfloat a,
		  GLfloat x,
		  GLfloat y,
		  GLfloat z)
{
  GLfloat r[16];
  my_glLoadIdentity(r);
        
  a = DEGREE_TO_RADIAN(a);
  if(((x == 1) || (x == -1)) &&
     (y == 0) && (z == 0))
    {
      if(x == -1)
	{
	  a = -a;
	}
      float c_a = cosf(a);
      float s_a = sinf(a);
      r[5]  =  c_a;
      r[6]  =  s_a;
      r[9]  = -s_a;
      r[10] =  c_a;
    }
  else if(((y == 1) || (y == -1)) &&
	  (x == 0) && (z == 0))
    {
      if(y == -1)
	{
	  a = -a;
	}
      float c_a = cosf(a);
      float s_a = sinf(a);
      r[0]  =  c_a;
      r[2]  = -s_a;
      r[8]  =  s_a;
      r[10] =  c_a;

    }
  else if(((z == 1) || (z == -1)) &&
	  (x == 0) && (y == 0))
    {
      if(z == -1)
	{
	  a = -a;
	}
      float c_a = cosf(a);
      float s_a = sinf(a);
      r[0] =  c_a;
      r[1] =  s_a;
      r[4] = -s_a;
      r[5] =  c_a;

    }
  else
    {
      return;
    }
  my_glMultMatrix(m, r);
}

void my_glScalef(GLfloat * m, GLfloat x, GLfloat y, GLfloat z)
{
  GLfloat s[16];
  my_glLoadIdentity(s);
  s[0]  = x;
  s[5]  = y;
  s[10] = z;

  my_glMultMatrix(m, s);
}


#define STACK_SIZE 4
static GLfloat stack[STACK_SIZE][16];
static unsigned top = 0;

void my_glPushMatrix(GLfloat * m)
{
  if(top < STACK_SIZE)
    {
      memcpy(&stack[top][0], m, 16 * sizeof(*m));
      top++;
    }
}

void my_glPopMatrix(GLfloat * m)
{
  if(1 < top)
    {
      top--;
      memcpy(m, &stack[top][0], 16 * sizeof(*m));
    }
}
