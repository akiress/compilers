#ifndef __utils_h__
#define __utils_h__

#include "common.h"

void my_glMultMatrix(GLfloat* m1, const GLfloat* m2);
void my_glLoadIdentity(GLfloat * m);
void my_gluPerspective(GLfloat * m, GLfloat fovy, GLfloat aspect, GLfloat near, GLfloat far);
void my_glTranslatef(GLfloat * m, GLfloat x, GLfloat y, GLfloat z);
void my_glRotatef(GLfloat * m, GLfloat a, GLfloat x, GLfloat y, GLfloat z);
void my_glScalef(GLfloat * m, GLfloat x, GLfloat y, GLfloat z);
void my_glPushMatrix(GLfloat * m);
void my_glPopMatrix(GLfloat * m);

#endif
