#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include "shader.h"

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

typedef enum shader_type_e
  {
    Vert = 0,
    Frag,
    NbShaderTypes
  } shader_type_t;

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

typedef struct
{
  char * name;
  char * beg;
  char * end;
} embedded_shader_t;

extern const embedded_shader_t embedded_shaders[];
extern const unsigned embedded_shaders_cnt;

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

struct shader_s
{
  // Shader identifiers
  GLuint  vert_shader_id;
  GLuint  frag_shader_id;

  // Program identifiers
  GLuint  prog_id;
};

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static void check_shader_log(GLuint obj)
{
  int infologLength = 0;
  int charsWritten  = 0;
  char *infoLog;
 
  glGetShaderiv(obj, GL_INFO_LOG_LENGTH, &infologLength);
  if (infologLength > 0)
    {
      fprintf(stderr, "shader log : ");
      infoLog = (char *)malloc(infologLength);
      glGetShaderInfoLog(obj, infologLength, &charsWritten, infoLog);
      fprintf(stderr, "%s\n",infoLog);
      free(infoLog);
    }
}

#define CHECK_SHADER_LOG(obj)  do { check_shader_log(obj);  } while(0)

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static void check_program_log(GLuint obj)
{
  int infologLength = 0;
  int charsWritten  = 0;
  char *infoLog;
 
  glGetProgramiv(obj, GL_INFO_LOG_LENGTH,&infologLength);
 
  if (infologLength > 0)
    {
      fprintf(stderr, "program log : ");
      infoLog = (char *)malloc(infologLength);
      glGetProgramInfoLog(obj, infologLength, &charsWritten, infoLog);
      fprintf(stderr, "%s\n",infoLog);
      free(infoLog);
    }
}

#define CHECK_PROGRAM_LOG(obj) do { check_program_log(obj); } while(0)

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static GLchar * shader_source_load(const char *prefix, const char * ext)
{
  GLchar * file_data = 0;

  //
  const char * shaders_path;
  shaders_path = getenv("SHADERS_PATH");
  if(!shaders_path)
    {
      fprintf(stderr, "SHADERS_PATH not defined, will use \".\"\n");
      shaders_path = ".";
    }

  // compute file name 
  char file_name[FILENAME_MAX];
  snprintf(file_name, sizeof(file_name), "%s/%s.%s", shaders_path, prefix, ext);
  
  // open file
  FILE *fp;
  fprintf(stdout, "Open %s\n", file_name);
  fp = fopen(file_name, "r");
  if(fp)
    {
      // compute file size
      int file_size;
      fseek(fp, 0, SEEK_END);
      file_size = ftell(fp);
      if(file_size <= 0)
        {
          perror("fseek failed");
          fclose(fp);
          return 0;
        }

      // alloc for data
      file_data = malloc(file_size + 1);
      if(!file_data)
        {
          fprintf(stderr, "not enought memory\n");
          fclose(fp);
          return 0;
        }

      // read data
      fseek(fp, 0, SEEK_SET);
      int nb_read;
      nb_read = fread(file_data, file_size, 1, fp);
      if(nb_read != 1)
        {
          perror("fread failed");
          free(file_data);
          fclose(fp);
          return 0;
        }

      file_data[file_size] = '\0';
 
      fclose(fp);
    }
  else
    {
      fprintf(stderr, "fopen \"%s\" failed : %s\n", file_name, strerror(errno));
      snprintf(file_name, sizeof(file_name), "%s.%s", prefix, ext);
      int i = 0;
      while(i < embedded_shaders_cnt)
        {
	  if(strcmp(file_name, embedded_shaders[i].name) == 0)
            {
              break;
            }
	  i++;
        }
      if(i < embedded_shaders_cnt)
        {
          fprintf(stderr, "fallback to embedded shaders\n");
          file_data = strndup(embedded_shaders[i].beg,
                              embedded_shaders[i].end - embedded_shaders[i].beg);
          if(!file_data)
            {
              perror("strndup failed");
            }
        }
    }

  return file_data;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
shader_t * shader_alloc(void)
{
  shader_t * shader = calloc(1, sizeof(*shader));
  return shader;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
void shader_free(shader_t *shader)
{
  if(shader)
    {
      shader_kill(shader);
      free(shader);
    }
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

int shader_init(shader_t *shader, const char * prefix)
{
  if(!shader)
    {
      return -1;
    }  

  // Create a vertex shader object and a fragment shader object

  shader->vert_shader_id = glCreateShader(GL_VERTEX_SHADER);
  shader->frag_shader_id = glCreateShader(GL_FRAGMENT_SHADER);
  if(!shader->vert_shader_id || !shader->frag_shader_id)
    {
      fprintf(stderr, "Shader creation failed\n");
      shader_kill(shader);
      return -1;
    }

  // Load source code strings into shaders

  GLchar * vert_shader_src = shader_source_load(prefix, VERT_SHADER_EXT);
  if(!vert_shader_src)
    {
      shader_kill(shader);
      return -1;
    }
  GLchar * frag_shader_src = shader_source_load(prefix, FRAG_SHADER_EXT);
  if(!frag_shader_src)
    {
      free(vert_shader_src);
      shader_kill(shader);
      return -1;
    }

  // debug
  fprintf(stdout, "--------------------------------------\n");
  fprintf(stdout, "%s", vert_shader_src);
  fprintf(stdout, "--------------------------------------\n");
  fprintf(stdout, "%s", frag_shader_src);
  fprintf(stdout, "--------------------------------------\n");

  glShaderSource(shader->vert_shader_id, 1, (const GLchar **)&vert_shader_src, NULL);
  glShaderSource(shader->frag_shader_id, 1, (const GLchar **)&frag_shader_src, NULL);

  // Compile vertex shader, and print out the compiler log file.

  glCompileShader(shader->vert_shader_id);
  CHECK_SHADER_LOG(shader->vert_shader_id);

  // Compile framgent shader, and print out the compiler log file.

  glCompileShader(shader->frag_shader_id);
  CHECK_SHADER_LOG(shader->frag_shader_id);

  // free source
  free(vert_shader_src);
  free(frag_shader_src);

  // check compilation result
  GLint vert_compiled;
  GLint frag_compiled;
  glGetShaderiv(shader->vert_shader_id, GL_COMPILE_STATUS, &vert_compiled);
  glGetShaderiv(shader->frag_shader_id, GL_COMPILE_STATUS, &frag_compiled);
  if(!vert_compiled || !frag_compiled)
    {
      fprintf(stderr, "Shader compilation failed\n");
      CHECK_GL_ERROR();
      shader_kill(shader);
      return -1;
    }

  // Create a program object and attach the two compiled shaders

  shader->prog_id = glCreateProgram();
  if(!shader->prog_id)
    {
      fprintf(stderr, "Shader program creation failed\n");
      shader_kill(shader);
      return -1;
    }
  glAttachShader(shader->prog_id, shader->vert_shader_id);
  glAttachShader(shader->prog_id, shader->frag_shader_id);

  // Link the program object and print out the info log

  glLinkProgram(shader->prog_id);
  CHECK_PROGRAM_LOG(shader->prog_id);

  // check linking result
  GLint prog_linked;
  glGetProgramiv(shader->prog_id, GL_LINK_STATUS, &prog_linked);
  if(!prog_linked)
    {
      fprintf(stderr, "Shader linking failed\n");
      CHECK_GL_ERROR();
      shader_kill(shader);
      return -1;
    }

  //
#if !defined(USE_GLES2_GL2)
  glBindFragDataLocation(shader->prog_id, 0, "out_Color");
#endif

  return 0;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

void shader_kill(shader_t *shader)
{
  if(!shader)
    {
      return;
    }

  glUseProgram(0);

  if(shader->prog_id)
    {
      glDetachShader(shader->prog_id, shader->vert_shader_id);
      glDetachShader(shader->prog_id, shader->frag_shader_id);
      glDeleteProgram(shader->prog_id);
      shader->prog_id = 0;
    }

  if(shader->vert_shader_id)
    {
      glDeleteShader(shader->vert_shader_id);
      shader->vert_shader_id = 0;
    }

  if(shader->frag_shader_id)
    {
      glDeleteShader(shader->frag_shader_id);
      shader->frag_shader_id = 0;
    }
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
GLuint shader_get_prog_id(shader_t *shader)
{
  return shader->prog_id;
}
