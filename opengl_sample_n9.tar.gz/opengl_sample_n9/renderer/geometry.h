#ifndef __geometry_h__
#define __geometry_h__

#include "common.h"

typedef enum 
  {
    Quad = 0,
    Cube,
    Disk,
    Sphere,
    NumGeometries
  } geometry_type_t;

int  geometry_init(GLint program);
void geometry_kill(void);
void geometry_draw(geometry_type_t type, GLfloat *projection, GLfloat *viewing, GLfloat *modeling);

#endif /* __geometry_h__ */
