#ifndef __shader_h__
#define __shader_h__

#include "common.h"

typedef struct shader_s shader_t;


shader_t * shader_alloc(void);
void       shader_free(shader_t *shader);

int        shader_init(shader_t *shader, const char * prefix);
void       shader_kill(shader_t *shader);

GLuint     shader_get_prog_id(shader_t *shader);

#endif /* __shader_h__ */

