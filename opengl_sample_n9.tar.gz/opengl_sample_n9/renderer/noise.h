#ifndef __noise_h__
#define __noise_h__

#include "common.h"

int  noise_init(GLint program);
void noise_kill(void);
void noise_update(double date);

#endif /* __noise_h__ */
