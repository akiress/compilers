#include <stdlib.h>
#include <stdio.h>

#include "renderer.h"

#include "common.h"
#include "utils.h"
#include "shader.h"
#include "noise.h"
#include "geometry.h"

/*****************************************************************************
 * view state                                                                *
 *****************************************************************************/

typedef struct 
{
  float theta;
  float psi;
  float distance;
} view_state_t;

static view_state_t view_state = {0, 0, 6};

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static GLfloat viewing_matrix[16];
static GLfloat modeling_matrix[16];
static GLfloat projection_matrix[16];

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
void renderer_reshape(int w, int h)
{
    glViewport(0, 0, w, h);

    my_glLoadIdentity(projection_matrix);
    my_gluPerspective(projection_matrix, 45.0, (float)w / h, 0.01, 40.0);
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
void renderer_move(float d_theta, float d_psi, float d_distance)
{
  view_state.theta    += d_theta;
  view_state.psi      += d_psi;
  view_state.distance += d_distance;

  if(0 < view_state.theta)
    {
      view_state.theta = 0;
    }
  if(view_state.theta < -180)
    {
      view_state.theta = -180;
    }
  while(360 <= view_state.psi)
    {
      view_state.psi -= 360;
    }
  while(view_state.psi < 0)
    {
      view_state.psi += 360;
    }
  if(view_state.distance < 1.0)
    {
      view_state.distance = 1.0;
    }
  if(40.0 < view_state.distance)
    {
      view_state.distance = 40.0;
    }
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
void renderer_display(double date)
{
  noise_update(date);

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  /* view */
  my_glLoadIdentity(viewing_matrix);
  my_glTranslatef(viewing_matrix, 0.0, 0.0, -view_state.distance);
  my_glRotatef(viewing_matrix, view_state.theta, 1.0, 0.0, 0.0);
  my_glRotatef(viewing_matrix, view_state.psi, 0.0, 0.0, 1.0);

  /* modeling */
  my_glLoadIdentity(modeling_matrix);
  
  my_glPushMatrix(modeling_matrix);
  my_glTranslatef(modeling_matrix, 1,1,0);
  geometry_draw(Quad, projection_matrix, viewing_matrix, modeling_matrix);
  my_glPopMatrix(modeling_matrix);

  my_glPushMatrix(modeling_matrix);
  my_glTranslatef(modeling_matrix, 1,-1,0);
  geometry_draw(Cube, projection_matrix, viewing_matrix, modeling_matrix);
  my_glPopMatrix(modeling_matrix);

  my_glPushMatrix(modeling_matrix);
  my_glTranslatef(modeling_matrix, -1,-1,0);
  geometry_draw(Disk, projection_matrix, viewing_matrix, modeling_matrix);
  my_glPopMatrix(modeling_matrix);

  my_glPushMatrix(modeling_matrix);
  my_glTranslatef(modeling_matrix, -1,1,0);
  geometry_draw(Sphere, projection_matrix, viewing_matrix, modeling_matrix);
  my_glPopMatrix(modeling_matrix);

  my_glPushMatrix(modeling_matrix);
  my_glTranslatef(modeling_matrix, 0,0,-1);
  my_glScalef(modeling_matrix, 4,4,0);
  geometry_draw(Quad, projection_matrix, viewing_matrix, modeling_matrix);
  my_glPopMatrix(modeling_matrix);

  //CHECK_GL_ERROR();
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
void gl_init(void)
{
  glClearColor(0.0,0.0,0.0,0.0);

  glEnable(GL_CULL_FACE);
  glCullFace(GL_BACK);
  glFrontFace(GL_CCW);

  //glEnable(GL_BLEND);
  //glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

  // FIXME blending plus depth test isn't a good idea

  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LESS);
 }

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static shader_t * shader = 0;

static int misc_init(void)
{
  fprintf(stdout, "Alloc shader\n");
  shader = shader_alloc();
  if(!shader)
    {
      fprintf(stderr, "Alloc shader : failed\n");
      return -1;
    }

  int err;
  fprintf(stdout, "Init shader\n");
  err = shader_init(shader, "fire");
  if(err)
    {
      fprintf(stderr, "Init shader : failed\n");
      return -1;
    }

  fprintf(stdout, "Init noise\n");
  err = noise_init(shader_get_prog_id(shader));
  if(err)
    {
      fprintf(stderr, "Init noise : failed\n");
      return -1;
    }

  fprintf(stdout, "Init geometry\n");
  err = geometry_init(shader_get_prog_id(shader));
  if(err)
    {
      fprintf(stderr, "Init geometry : failed\n");
      return -1;
    }

  return 0;
}

static void misc_kill(void)
{
  fprintf(stdout, "Cleanup geometry\n");
  geometry_kill();
  
  fprintf(stdout, "Cleanup noise\n");
  noise_kill();

  fprintf(stdout, "Cleanup shader\n");
  shader_kill(shader);
  
  fprintf(stdout, "Free shader\n");
  shader_free(shader);
  shader = 0;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
int renderer_init(void)
{
  CLEAR_GL_ERROR();
  gl_init();
  int err;
  err = misc_init();
  if(err)
    {
      misc_kill();
    }
  CHECK_GL_ERROR();
  return err;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
void renderer_kill(void)
{
  misc_kill();
}
