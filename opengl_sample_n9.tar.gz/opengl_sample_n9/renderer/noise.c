#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "noise.h"
#include "noise_data.h"

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

typedef enum 
  {
    PerlinLookup = 0,
    Date,
    NumUniforms
  } uniforms_type_t ;

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

#define PERLIN_LOOKUP_SZ 256
#define PERLIN_LOOKUP_DEPTH 4
static unsigned char perlin_lookup_data[PERLIN_LOOKUP_SZ][PERLIN_LOOKUP_SZ][PERLIN_LOOKUP_DEPTH];

static void noise_init_perlin_lookup()
{
      int y;
      for(y = 0; y < PERLIN_LOOKUP_SZ; y++)
	{
	  int x;
	  for(x = 0; x < PERLIN_LOOKUP_SZ; x++)
	    {
	      unsigned char perm = p(p(x) + y);
	      const char * grad = g(perm);
	      perlin_lookup_data[y][x][0] = grad[0] * 64 + 64;
	      perlin_lookup_data[y][x][1] = grad[1] * 64 + 64;
	      perlin_lookup_data[y][x][2] = grad[2] * 64 + 64;
	      perlin_lookup_data[y][x][3] = perm;
	    }
    }
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static const char * uniforms_names[NumUniforms] = 
  {
    "PerlinLookup",
    "Date"
  };

static GLuint uniforms_indices[NumUniforms] = {GL_INVALID_INDEX};

static int noise_init_uniforms(GLint program)
{
  int i;
  for(i = 0; i < NumUniforms; i++)
    {
      uniforms_indices[i] = glGetUniformLocation(program, uniforms_names[i]);
    }

  int err = 0;
  /* make some sanity checks */
  for(i = 0; i < NumUniforms; i++)
    {
      if(uniforms_indices[i] == GL_INVALID_INDEX)
	{
	  fprintf(stderr, "\"%s\" uniform index is --.\n", uniforms_names[i]);
	  err = -1;
	}
      else
	{
          fprintf(stdout, "\"%s\" uniform index is %d.\n", uniforms_names[i], uniforms_indices[i]);
	}
    }

  return err;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static GLuint tex_name[NumUniforms] = {0};

static int noise_init_textures(void)
{
  glGenTextures(NumUniforms, tex_name);

  glBindTexture(GL_TEXTURE_2D, tex_name[PerlinLookup]);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

#if defined(USE_GLES2_GL2)
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, PERLIN_LOOKUP_SZ, PERLIN_LOOKUP_SZ, 0, GL_RGBA, GL_UNSIGNED_BYTE, perlin_lookup_data);
#else
  glTexImage2D(GL_TEXTURE_2D, 0, GL_COMPRESSED_RGBA, PERLIN_LOOKUP_SZ, PERLIN_LOOKUP_SZ, 0, GL_RGBA, GL_UNSIGNED_BYTE, perlin_lookup_data);
  GLboolean t_compressed = GL_FALSE;
  glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_COMPRESSED, (GLint *)&t_compressed);
  if(t_compressed == GL_TRUE)
    {
      GLenum t_internal_format;
      GLsizei t_image_size;
      GLsizei image_size = sizeof(perlin_lookup_data);
      glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_INTERNAL_FORMAT, (GLint *)&t_internal_format);
      glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_COMPRESSED_IMAGE_SIZE, (GLint *)&t_image_size);
      fprintf(stdout, "Noise perlin lookup compressed : original size %d, compressed size %d (%d%%) (internal format 0x%08x)\n",
	      image_size,
	      t_image_size,
	      t_image_size * 100 / image_size,
	      t_internal_format);
    }
#endif

  return 0;
}

static void noise_kill_textures(void)
{
  glDeleteTextures(NumUniforms, tex_name);
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static GLint program_id;

int noise_init(GLint program)
{
  if(!glIsProgram(program))
    {
      return - 1;
    }
  program_id = program;

  noise_init_perlin_lookup();

  noise_init_uniforms(program_id);

  noise_init_textures();

  glUseProgram(program_id);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, tex_name[PerlinLookup]);
  glUniform1i(uniforms_indices[PerlinLookup], 0);

  return 0;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
void noise_kill(void)
{
  noise_kill_textures();
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
void noise_update(double date)
{
  /* need to scale date to cast to float */
  static double start_date = 0;
  if(!start_date)
    {
      start_date = date;
    }
  
  GLfloat t = (date - start_date) / 4.0; 

  glUseProgram(program_id);
  glUniform1f(uniforms_indices[Date], (GLfloat)(t));
}
