#ifndef __renderer_h__
#define __renderer_h__

#ifdef __cplusplus
extern "C" {
#endif 

int renderer_init(void);

void renderer_reshape(int w, int h);

void renderer_move(float d_theta, float d_psi, float d_distance);

void renderer_display(double date);

void renderer_kill(void);

#ifdef __cplusplus
}
#endif 

#endif /* __renderer_h__ */
