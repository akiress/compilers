#include <stdio.h>

#include "common.h"

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

#if !defined(gluErrorString)
static const GLubyte *gluErrorString(GLenum error)
{
    switch(error)
    {
    case GL_NO_ERROR:
        return (const GLubyte *)"GL_NO_ERROR ";
    case GL_INVALID_ENUM:
        return (const GLubyte *)"GL_INVALID_ENUM ";
    case GL_INVALID_VALUE:
        return (const GLubyte *)"GL_INVALID_VALUE ";
    case GL_INVALID_OPERATION:
        return (const GLubyte *)"GL_INVALID_OPERATION ";
    case GL_OUT_OF_MEMORY:
        return (const GLubyte *)"GL_OUT_OF_MEMORY ";
    default:
        return (const GLubyte *)"?";
    }
}
#endif

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

void clear_gl_error()
{
  GLenum err = glGetError();
  if(err != GL_NO_ERROR)
    {
      fprintf(stderr, "Purge gl errors :\n");
      while(err != GL_NO_ERROR)
	{
	  fprintf(stderr, "  %s\n", gluErrorString(err));
	  err = glGetError();
	}
    }
}
 
/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

void check_gl_error(const char * file, int line)
{
  GLenum err = glGetError();
  if(err != GL_NO_ERROR)
    {
      fprintf(stderr, "gl error in file %s @ line %d:\n", file, line);
      while(err != GL_NO_ERROR)
	{
	  fprintf(stderr, "  %s\n", gluErrorString(err));
	  err = glGetError();
	}
    }
}
 

