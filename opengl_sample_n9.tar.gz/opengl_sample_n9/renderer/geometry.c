#include <stdio.h>
#include <math.h>
#include <stddef.h>

#include "geometry.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846  /* pi */
#endif

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

typedef struct
{
  GLfloat pos[4];
  GLfloat col[4];
  GLfloat nor[3];
  GLfloat tex[3];
} vertex_data_t;

typedef struct
{
  /* data for the vertex buffer object */
  GLvoid *   data;
  GLsizeiptr data_size;

  /* set the mode and count param of glDrawArrays*/
  GLenum     mode;
  GLsizei    count;

  /* buffer objects */
  GLuint     vao; /* vertex array */
  GLuint     vbo; /* vertex buffer object */
#if defined(USE_UNIFORM_BLOCK_OBJECT)
  GLuint     ubo; /* uniform buffer object */
#endif
} geometry_t;

static geometry_t geometries[NumGeometries];
static GLint program_id;

/*****************************************************************************
 *  QUAD                                                                     *
 *****************************************************************************/

#define QUAD_NB_VERTICES 4
static vertex_data_t quad_data[QUAD_NB_VERTICES] = 
  {
    {{-0.5,-0.5, 0.0, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0, 1.0}, {0.0, 0.0, 0.0}}, // z-top
    {{ 0.5,-0.5, 0.0, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0, 1.0}, {1.0, 0.0, 0.0}},
    {{-0.5, 0.5, 0.0, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0, 1.0}, {0.0, 1.0, 0.0}},
    {{ 0.5, 0.5, 0.0, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0, 1.0}, {1.0, 1.0, 0.0}},
  };

static void geometry_init_quad(void)
{
  geometries[Quad].data  = quad_data;
  geometries[Quad].data_size = sizeof(quad_data);
  geometries[Quad].mode  = GL_TRIANGLE_STRIP;
  geometries[Quad].count = sizeof(quad_data) / sizeof(quad_data[0]);
}

/*****************************************************************************
 *  CUBE                                                                     *
 *****************************************************************************/

#define CUBE_NB_VERTICES 36
static vertex_data_t cube_data[CUBE_NB_VERTICES] = 
  {
    {{-0.5,-0.5, 0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0, 1.0}, {0.0, 0.0, 0.0}}, // z-top
    {{ 0.5,-0.5, 0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0, 1.0}, {1.0, 0.0, 0.0}},
    {{ 0.5, 0.5, 0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0, 1.0}, {1.0, 1.0, 0.0}},
									          
    {{ 0.5, 0.5, 0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0, 1.0}, {1.0, 1.0, 0.0}},
    {{-0.5, 0.5, 0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0, 1.0}, {0.0, 1.0, 0.0}},
    {{-0.5,-0.5, 0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0, 1.0}, {0.0, 0.0, 0.0}},
									          
    {{-0.5,-0.5,-0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0,-1.0}, {1.0, 1.0, 0.0}}, // z-down
    {{-0.5, 0.5,-0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0,-1.0}, {1.0, 0.0, 0.0}},
    {{ 0.5, 0.5,-0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0,-1.0}, {0.0, 0.0, 0.0}},
                       	                        		    	          
    {{ 0.5, 0.5,-0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0,-1.0}, {0.0, 0.0, 0.0}},
    {{ 0.5,-0.5,-0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0,-1.0}, {0.0, 1.0, 0.0}},
    {{-0.5,-0.5,-0.5, 1.0}, {0.0, 0.0, 1.0, 1.0}, { 0.0, 0.0,-1.0}, {1.0, 1.0, 0.0}},

    {{-0.5, 0.5,-0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0, 1.0, 0.0}, {0.0, 0.0, 0.0}}, // y-top
    {{-0.5, 0.5, 0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0, 1.0, 0.0}, {1.0, 0.0, 0.0}},
    {{ 0.5, 0.5, 0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0, 1.0, 0.0}, {1.0, 1.0, 0.0}},
                                                		    	          
    {{ 0.5, 0.5, 0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0, 1.0, 0.0}, {1.0, 1.0, 0.0}},
    {{ 0.5, 0.5,-0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}},
    {{-0.5, 0.5,-0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0, 1.0, 0.0}, {0.0, 0.0, 0.0}},
				            				          
    {{-0.5,-0.5,-0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0,-1.0, 0.0}, {1.0, 1.0, 0.0}}, // y-down
    {{ 0.5,-0.5,-0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0,-1.0, 0.0}, {1.0, 0.0, 0.0}},
    {{ 0.5,-0.5, 0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0,-1.0, 0.0}, {0.0, 0.0, 0.0}},
                                                		    	          
    {{ 0.5,-0.5, 0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0,-1.0, 0.0}, {0.0, 0.0, 0.0}},
    {{-0.5,-0.5, 0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0,-1.0, 0.0}, {0.0, 1.0, 0.0}},
    {{-0.5,-0.5,-0.5, 1.0}, {0.0, 1.0, 0.0, 1.0}, { 0.0,-1.0, 0.0}, {1.0, 1.0, 0.0}},

    {{ 0.5,-0.5,-0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, { 1.0, 0.0, 0.0}, {0.0, 0.0, 0.0}}, // x-top
    {{ 0.5, 0.5,-0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, { 1.0, 0.0, 0.0}, {1.0, 0.0, 0.0}},
    {{ 0.5, 0.5, 0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, { 1.0, 0.0, 0.0}, {1.0, 1.0, 0.0}},
                                                		    	          
    {{ 0.5, 0.5, 0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, { 1.0, 0.0, 0.0}, {1.0, 1.0, 0.0}},
    {{ 0.5,-0.5, 0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, { 1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}},
    {{ 0.5,-0.5,-0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, { 1.0, 0.0, 0.0}, {0.0, 0.0, 0.0}},
			          	       				          
    {{-0.5,-0.5,-0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, {-1.0, 0.0, 0.0}, {1.0, 1.0, 0.0}}, // x-down
    {{-0.5,-0.5, 0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, {-1.0, 0.0, 0.0}, {1.0, 0.0, 0.0}},
    {{-0.5, 0.5, 0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, {-1.0, 0.0, 0.0}, {0.0, 0.0, 0.0}},
                                                		    	          
    {{-0.5, 0.5, 0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, {-1.0, 0.0, 0.0}, {0.0, 0.0, 0.0}},
    {{-0.5, 0.5,-0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, {-1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}},
    {{-0.5,-0.5,-0.5, 1.0}, {1.0, 0.0, 0.0, 1.0}, {-1.0, 0.0, 0.0}, {1.0, 1.0, 0.0}},
  };

static void geometry_init_cube(void)
{
  geometries[Cube].data  = cube_data;
  geometries[Cube].data_size = sizeof(cube_data);
  geometries[Cube].mode  = GL_TRIANGLES;
  geometries[Cube].count = sizeof(cube_data) / sizeof(cube_data[0]);
}

/*****************************************************************************
 *  DISK                                                                   *
 *****************************************************************************/

#define DISK_NB_ARC 36
static vertex_data_t disk_data[2 + DISK_NB_ARC] = {{{0,0,0,0},{0,0,0,0},{0,0,0},{0,0,0}}};

static void geometry_init_disk(void)
{
  float arc = 2.0 * M_PI / DISK_NB_ARC;  /* size of an arc */
  int nb_arc = DISK_NB_ARC;              /* number of arcs on a 2PI perimeter */
  int n = 0;

  disk_data[n].pos[0] = 0;
  disk_data[n].pos[1] = 0;
  disk_data[n].pos[2] = 0;
  disk_data[n].pos[3] = 1;

  disk_data[n].col[0] = 1;
  disk_data[n].col[1] = 0;
  disk_data[n].col[2] = 0;
  disk_data[n].col[3] = 1;

  disk_data[n].nor[0] = 0;
  disk_data[n].nor[1] = 0;
  disk_data[n].nor[2] = 1;

  disk_data[n].tex[0] = 0.5;
  disk_data[n].tex[1] = 0.5;
  disk_data[n].tex[2] = 0.0;

  n++;

  int phi; /* longitude */
  for(phi = 0; phi <= nb_arc; phi++)
    {
      float x = cos(arc * phi);
      float y = sinf(arc * phi);

      disk_data[n].pos[0] = 0.5 * x;
      disk_data[n].pos[1] = 0.5 * y;
      disk_data[n].pos[2] = 0;
      disk_data[n].pos[3] = 1;

      disk_data[n].col[0] = x;
      disk_data[n].col[1] = y;
      disk_data[n].col[2] = 0;
      disk_data[n].col[3] = 1;

      disk_data[n].nor[0] = 0;
      disk_data[n].nor[1] = 0;
      disk_data[n].nor[2] = 1;

      disk_data[n].tex[0] = 0.5 + 0.5 * x;
      disk_data[n].tex[1] = 0.5 + 0.5 * y;
      disk_data[n].tex[2] = 0.0;

      n++;
    }            

  geometries[Disk].data  = disk_data;
  geometries[Disk].data_size = sizeof(disk_data);
  geometries[Disk].mode  = GL_TRIANGLE_FAN;
  geometries[Disk].count = sizeof(disk_data) / sizeof(disk_data[0]);
}


/*****************************************************************************
 *  SPHERE                                                                   *
 *****************************************************************************/

#define SPHERE_NB_ARC 36
static vertex_data_t sphere_data[2 * SPHERE_NB_ARC * SPHERE_NB_ARC] = {{{0,0,0,0},{0,0,0,0},{0,0,0},{0,0,0}}};

static void geometry_init_sphere(void)
{
  float arc = 2.0 * M_PI / SPHERE_NB_ARC;  /* size of an arc */
  int nb_arc = SPHERE_NB_ARC;              /* number of arcs on a 2PI perimeter */
  int n = 0;
  int theta; /* latitude */
  for(theta = 0; theta < nb_arc / 2; theta++)
    {
      int phi; /* longitude */
      for(phi = 0; phi < nb_arc; phi++)
	{
          int i;
          for(i = 0; i < 4; i++)
	    {
	      int t = theta + (i % 2);
	      int p = phi   + (i > 1);
	      float x = sinf(arc * t) * cosf(arc * p);
              float y = sinf(arc * t) * sinf(arc * p);
              float z = cosf(arc * t);

              sphere_data[n].pos[0] = 0.5 * x;
              sphere_data[n].pos[1] = 0.5 * y;
              sphere_data[n].pos[2] = 0.5 * z;
              sphere_data[n].pos[3] = 1;

              sphere_data[n].col[0] = x;
              sphere_data[n].col[1] = y;
              sphere_data[n].col[2] = z;
              sphere_data[n].col[3] = 1;

              sphere_data[n].nor[0] = x;
              sphere_data[n].nor[1] = y;
              sphere_data[n].nor[2] = z;

              sphere_data[n].tex[0] = 0.5 + 0.5 * x;
              sphere_data[n].tex[1] = 0.5 + 0.5 * y;
              sphere_data[n].tex[2] = 0;

              n++;
	    }            
	}
    }

  geometries[Sphere].data  = sphere_data;
  geometries[Sphere].data_size = sizeof(sphere_data);
  geometries[Sphere].mode  = GL_TRIANGLE_STRIP;
  geometries[Sphere].count = sizeof(sphere_data) / sizeof(sphere_data[0]);
}


/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

typedef enum 
  {
    Projection = 0,
    Viewing,
    Modeling,
    NumUniforms
  } uniforms_type_t ;

#if defined(USE_UNIFORM_BLOCK_OBJECT)
static const char * uniforms_block_name = "Transformation";
#endif

static const char * uniforms_names[NumUniforms] = 
  {
    "Projection",
    "Viewing",
    "Modeling",
  };

#if defined(USE_UNIFORM_BLOCK_OBJECT)
static GLuint uniforms_block_index = GL_INVALID_INDEX;
static GLint  uniforms_block_size = 0;
#endif
static GLuint uniforms_indices[NumUniforms] = {GL_INVALID_INDEX};
#if defined(USE_UNIFORM_BLOCK_OBJECT)
static GLint  uniforms_type[NumUniforms] = {0};
static GLint  uniforms_size[NumUniforms] = {0};
static GLint  uniforms_offset[NumUniforms] = {0};
#endif

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static int geometry_init_uniforms(GLint program)
{
  int i;

#if defined(USE_UNIFORM_BLOCK_OBJECT)

  /* obtain the index of the uniform for a given program */
  uniforms_block_index = glGetUniformBlockIndex(program, uniforms_block_name);
  if(uniforms_block_index == GL_INVALID_INDEX)
    {
      fprintf(stderr, "No \"%s\" uniform block index.\n", uniforms_block_name);
      return -1;
    }

  /* obtain the size of the uniform as generated by the compiler */
  glGetActiveUniformBlockiv(program, uniforms_block_index, GL_UNIFORM_BLOCK_DATA_SIZE, &uniforms_block_size);

  /* obtain the index of the named uniform variables */
  glGetUniformIndices(program, NumUniforms, uniforms_names, uniforms_indices);
  
  /* obtain the type/size/offset of the named uniform variables */
  glGetActiveUniformsiv(program, NumUniforms, uniforms_indices, GL_UNIFORM_TYPE  , uniforms_type  );
  glGetActiveUniformsiv(program, NumUniforms, uniforms_indices, GL_UNIFORM_SIZE  , uniforms_size  );
  glGetActiveUniformsiv(program, NumUniforms, uniforms_indices, GL_UNIFORM_OFFSET, uniforms_offset);

  /* make some sanity checks */
  for(i = 0; i < NumUniforms; i++)
    {
      if((uniforms_type[i] != GL_FLOAT_MAT4) || (uniforms_size[i] != 1))
	{
	  fprintf(stderr, "Bad type/count for \"%s\".\n", uniforms_names[i]);
          uniforms_indices[i] = GL_INVALID_INDEX;
	}
    }

#if 1
  fprintf(stdout, "uniforms_block_name  = %s\n", uniforms_block_name);
  fprintf(stdout, " uniforms_block_index = %d\n", uniforms_block_index);
  fprintf(stdout, " uniforms_block_size  = %d\n", uniforms_block_size);
  for(i = 0; i < NumUniforms; i++)
    {
      fprintf(stdout, "  name   = %s\n", uniforms_names[i]);
      fprintf(stdout, "   indice = %d\n", uniforms_indices[i]);
      fprintf(stdout, "   type   = %d\n", uniforms_type[i]);
      fprintf(stdout, "   size   = %d\n", uniforms_size[i]);
      fprintf(stdout, "   offset = %d\n", uniforms_offset[i]);
    }
#endif

#else /* defined(USE_UNIFORM_BLOCK_OBJECT) */

  for(i = 0; i < NumUniforms; i++)
    {
      uniforms_indices[i] = glGetUniformLocation(program, uniforms_names[i]);
    }

#endif /* defined(USE_UNIFORM_BLOCK_OBJECT) */

  int err = 0;
  /* make some sanity checks */
  for(i = 0; i < NumUniforms; i++)
    {
      if(uniforms_indices[i] == GL_INVALID_INDEX)
	{
	  fprintf(stderr, "\"%s\" uniform index is --.\n", uniforms_names[i]);
	  err = -1;
	}
      else
	{
          fprintf(stdout, "\"%s\" uniform index is %d.\n", uniforms_names[i], uniforms_indices[i]);
	}
    }

  return err;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
static void geometry_set_uniforms(uniforms_type_t i, GLfloat *data, GLsizeiptr size)
{
  if(uniforms_indices[i] != GL_INVALID_INDEX)
    {
#if defined(USE_UNIFORM_BLOCK_OBJECT)
#if !defined(USE_VERTEX_ARRAY_OBJECT)
      glBindBuffer(GL_UNIFORM_BUFFER, geometries[i].ubo);
#endif
      glBufferSubData(GL_UNIFORM_BUFFER, uniforms_offset[i], size, data);
#else /* defined(USE_UNIFORM_BLOCK_OBJECT) */
      glUniformMatrix4fv(uniforms_indices[i], 1, GL_FALSE, data);
#endif
    }
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

typedef enum 
  {
    Position = 0,
    Color,
    Normal,
    TexCoord,
    NumAttributes
  } attributes_type_t;

static const char * attributes_names[NumAttributes] = 
  {
    "in_Position",
    "in_Color",
    "in_Normal",
    "in_TexCoord"
  };

static GLuint attributes_indices[NumAttributes] = {GL_INVALID_INDEX};

static const unsigned attributes_offsets[NumAttributes] =
  {
    offsetof(vertex_data_t, pos),
    offsetof(vertex_data_t, col),
    offsetof(vertex_data_t, nor),
    offsetof(vertex_data_t, tex),
  };
static const unsigned attributes_size[NumAttributes] = 
  {
    sizeof(((vertex_data_t *)0)->pos) / sizeof(((vertex_data_t *)0)->pos[0]),
    sizeof(((vertex_data_t *)0)->col) / sizeof(((vertex_data_t *)0)->col[0]),
    sizeof(((vertex_data_t *)0)->nor) / sizeof(((vertex_data_t *)0)->nor[0]),
    sizeof(((vertex_data_t *)0)->tex) / sizeof(((vertex_data_t *)0)->tex[0]),
  };

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

static int geometry_init_attributes(GLint program)
{
  int i;
  int err = 0;

  /* obtain the index of the named attributes variables */
  for(i = 0; i < NumAttributes; i++)
    {
      attributes_indices[i] = glGetAttribLocation(program, attributes_names[i]);
      if(attributes_indices[i] == GL_INVALID_INDEX)
	{
	  fprintf(stderr, "\"%s\" attribute index is --.\n", attributes_names[i]);
	  err = -1;
	}
      else
	{
          fprintf(stdout, "\"%s\" attribute index is %d.\n", attributes_names[i], attributes_indices[i]);
	}
    }

  return err;
}


/*****************************************************************************
 *                                                                           *
 *****************************************************************************/
int geometry_init_vao(void)
{
  int i;
  int j;

  for(i = 0; i < NumGeometries; i++)
    {
      /* bind the vertex array */
#if defined(USE_VERTEX_ARRAY_OBJECT)
      glGenVertexArrays(1, &geometries[i].vao);
      glBindVertexArray(geometries[i].vao);
#endif /* defined(USE_VERTEX_ARRAY_OBJECT) */

      /* bind the vertex buffer */
      glGenBuffers(1, &geometries[i].vbo);
      glBindBuffer(GL_ARRAY_BUFFER, geometries[i].vbo);
      glBufferData(GL_ARRAY_BUFFER, geometries[i].data_size, geometries[i].data, GL_STATIC_DRAW);
 
      for(j = 0; j < NumAttributes; j++)
	{
          if(attributes_indices[j] != GL_INVALID_INDEX)
	    {
	      glVertexAttribPointer(attributes_indices[j], attributes_size[j], GL_FLOAT, GL_FALSE, sizeof(vertex_data_t), (const GLvoid *)attributes_offsets[j]); 
	      glEnableVertexAttribArray(attributes_indices[j]);
	    }
	}

      /* bind the uniform buffer */
#if defined(USE_UNIFORM_BLOCK_OBJECT)
      glGenBuffers(1, &geometries[i].ubo);
      glBindBuffer(GL_UNIFORM_BUFFER, geometries[i].ubo);
      glBufferData(GL_UNIFORM_BUFFER, uniforms_block_size, 0, GL_DYNAMIC_DRAW);

      glBindBufferBase(GL_UNIFORM_BUFFER, uniforms_block_index, geometries[i].ubo);
#endif

    }

#if defined(USE_VERTEX_ARRAY_OBJECT)
  glBindVertexArray(0);
#endif /* defined(USE_VERTEX_ARRAY_OBJECT) */

  return 0;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

int geometry_init(GLint program)
{
  geometry_init_quad();
  geometry_init_cube();
  geometry_init_disk();
  geometry_init_sphere();
 
  if(!glIsProgram(program))
    {
      return - 1;
    }
  program_id = program;
  glUseProgram(program_id);
 
  geometry_init_uniforms(program_id);
  geometry_init_attributes(program_id);

  geometry_init_vao();
 
  return 0;
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

void geometry_kill(void)
{
  int i;

  glBindBuffer(GL_ARRAY_BUFFER, 0);
#if defined(USE_VERTEX_ARRAY_OBJECT)
  glBindVertexArray(0);
#endif /* defined(USE_VERTEX_ARRAY_OBJECT) */

  for(i = 0; i < NumGeometries; i++)
    {
#if defined(USE_UNIFORM_BLOCK_OBJECT)
      glDeleteBuffers(1, &geometries[i].ubo);
#endif
      glDeleteBuffers(1, &geometries[i].vbo);
#if defined(USE_VERTEX_ARRAY_OBJECT)
      glDeleteVertexArrays(1, &geometries[i].vao);
#endif /* defined(USE_VERTEX_ARRAY_OBJECT) */
    }
}

/*****************************************************************************
 *                                                                           *
 *****************************************************************************/

void geometry_draw(geometry_type_t type, GLfloat *projection, GLfloat *viewing, GLfloat *modeling)
{
  glUseProgram(program_id);

#if defined(USE_VERTEX_ARRAY_OBJECT)
  glBindVertexArray(geometries[type].vao);
#endif /* defined(USE_VERTEX_ARRAY_OBJECT) */

  geometry_set_uniforms(Projection, projection, 16 * sizeof(*projection));
  geometry_set_uniforms(Viewing   , viewing   , 16 * sizeof(*viewing));
  geometry_set_uniforms(Modeling  , modeling  , 16 * sizeof(*modeling));

#if !defined(USE_VERTEX_ARRAY_OBJECT)
  glBindBuffer(GL_ARRAY_BUFFER, geometries[type].vbo);
  int j;
  for(j = 0; j < NumAttributes; j++)
    {
      if(attributes_indices[j] != GL_INVALID_INDEX)
        {
          glVertexAttribPointer(attributes_indices[j], attributes_size[j], GL_FLOAT, GL_FALSE, sizeof(vertex_data_t), (const GLvoid *)attributes_offsets[j]);
          glEnableVertexAttribArray(attributes_indices[j]);
        }
    }
#endif

  glDrawArrays(geometries[type].mode, 0, geometries[type].count);
}
